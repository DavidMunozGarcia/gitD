package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import java.sql.Statement;

public class ConexionPostgres {

    Connection conexion;

    String cadenaConexion = "jdbc:postgresql://localhost:5432/GuiaPracticaMunoz";
    String usuarioPG = "postgres";
    String contraPG = "a";

    public ConexionPostgres() {
        try {
            Class.forName("org.postgresql.Driver");
            System.out.println("Driver OK");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionPostgres.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            conexion = DriverManager.getConnection(cadenaConexion, usuarioPG, contraPG);
            System.out.println("Conexión OK");
        } catch (SQLException ex) {
            Logger.getLogger(ConexionPostgres.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public ResultSet consultaBD(String sql) {
        try {
            Statement statement = conexion.createStatement();
            return statement.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionPostgres.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    }

    public boolean accionBD(String sql) {
        try {
            Statement statement = conexion.createStatement();
            statement.execute(sql);
            statement.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ConexionPostgres.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
}
