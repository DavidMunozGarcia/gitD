package Modelo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ModeloPersona extends Persona {

    ConexionPostgres conexionPostgres = new ConexionPostgres();

    public ModeloPersona() {

    }

    public List<Persona> listarPersonas() {
        List<Persona> listaPersonas = new ArrayList<>();

        try {
            String sql = "SELECT * FROM persona";
            ResultSet rs = conexionPostgres.consultaBD(sql);
            while (rs.next()) {
                Persona persona = new Persona();
                persona.setIdPersona(rs.getString("idPersona"));
                persona.setNombre(rs.getString("nombre"));
                persona.setApellido(rs.getString("apellido"));

                listaPersonas.add(persona);
            }
            rs.close();
            return listaPersonas;
        } catch (SQLException ex) {
            Logger.getLogger(ModeloPersona.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public boolean grabarPersona() {
        String sql = "INSERT INTO persona(idPersona, nombre, apellido)";
        sql += " VALUES ('" + getIdPersona() + "', '" + getNombre() + "', '" + getApellido() + "')";
        return conexionPostgres.accionBD(sql);
    }

    public boolean modificarPersona() {
        String sql = "UPDATE persona SET idPersona = '" + getIdPersona() + "', nombre = '" + getNombre() + "', apellido = '" + getApellido() + "' WHERE idPersona = '" + getIdPersona() + "'";
        return conexionPostgres.accionBD(sql);
    }

    public boolean eliminarPersona() {
        String sql = "DELETE FROM persona WHERE idPersona = '" + getIdPersona() + "'";
        return conexionPostgres.accionBD(sql);
    }

}
