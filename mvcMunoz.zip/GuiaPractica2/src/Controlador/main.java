package Controlador;

import Controlador.ControladorPersona;
import Modelo.ModeloPersona;
import Vista.MenuPrincipal;

public class main {

    public static void main(String[] args) {
        ModeloPersona modelo = new ModeloPersona();
        MenuPrincipal vista = new MenuPrincipal();
        ControladorPersona controlador = new ControladorPersona(modelo, vista);
        controlador.iniciarControl();
    }

}
